function setScopeParams(lib,FgParams)
calllib(lib,'SetScopeTimebase',2/(FgParams.frequency));